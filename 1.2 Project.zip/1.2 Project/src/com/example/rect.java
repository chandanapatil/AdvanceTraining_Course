package com.example;

import java.util.Scanner;

class rect {
	int length; 
    int breadth; 
    int area; 
   
    public rect()
    {
    	length = 0;
    	breadth= 0;
    }

    void input() {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = s.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = s.nextInt();
    }

    void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
       
    }

    public static void main(String args[]) {
        rect obj1 = new rect();
        obj1.input();
        obj1.calculate();
        obj1.display();
        System.out.println("*****************");
        rect obj2 = new rect();
        obj2.input();
        obj2.calculate();
        obj2.display();
        System.out.println("******************");
        rect obj3 = new rect();
        obj3.input();
        obj3.calculate();
        obj3.display();
        System.out.println("******************");
        rect obj4 = new rect();
        obj4.input();
        obj4.calculate();
        obj4.display();
        System.out.println("******************");
        rect obj5 = new rect();
        obj5.input();
        obj5.calculate();
        obj5.display();
    }
}
