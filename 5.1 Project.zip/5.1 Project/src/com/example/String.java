package com.example;

public class String {
public static void main(String[] args) {
			
		
		 java.lang.String str = "JAVA is Simple";
		
		System.out.println(str.toUpperCase()); //UpperCase
		
		System.out.println(str.toLowerCase()); //LowerCase
		
		
		String[] words=str.split("\\s");	//1st words of letter
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		
		String[] words1=str.split("\\s"); // Change order 
		for(String w:words1){  
			System.out.println(w); 
		}
		
		//String Builder reverse
		StringBuilder words2= new StringBuilder("JAVA is Simple");
		
		Object words21;
		System.out.println("String = " + words2.toString());
		StringBuilder reverseStr = words2.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
		//Total Length
		System.out.println("length of string " + txt.length());
	}

private java.lang.String length() {
	// TODO Auto-generated method stub
	return null;
}

private char[] charAt(int i) {
	// TODO Auto-generated method stub
	return null;
}

private String[] split(java.lang.String string) {
	// TODO Auto-generated method stub
	return null;
}

private char[] toLowerCase() {
	// TODO Auto-generated method stub
	return null;
}

private char[] toUpperCase() {
	// TODO Auto-generated method stub
	return null;
}
}
